#!/bin/bash
# Returns fail2ban status overview
# This script is whitelisted and executed via sudo

fail2ban-client status

